# Frequently asked questions

## General

- Who is Camilla?

  Camilla is my daughters middle name.

## Config files

- Why do I get a cryptic error message when my config file looks ok?
  
  In YAML it is very important that the indentation is correct, otherwise the parser is not able to deduce which properties belong to what level in the tree.
  This can result in an error message like this:
  ```
  ERRO Invalid config file!
  mapping values are not allowed in this context at line 12 column 13, module: camilladsp 
  ```
  Check the file carefully, to make sure everything is properly indented. Use only spaces, never tabs.

## Capture and playback

- Why do I get buffer underruns sometimes even if everything looks correct?

  If the playback sound card and the capture sound card have independent sample clocks, then they will never be perfectly synchronized. One of them will always run slightly faster than the other. If the playback device is the faster one, then it will sometimes run out of data to play. This will lead to almost periodic dropouts. If instead the capture device is the faster one, then there will instead be a slowly increasing delay between input and output.

  Use the `enable_rate_adjust` option (with the asynchronous resampler if needed) to match the rates of the capture and playback devices. 

- Why do I get only distorted noise when using 24-bit samples?

  There are a total of three different 24-bit formats, and it's very important to pick the right one. All use three bytes to store each sample value, but they are packed in different ways.

  - S24_3_LE: Here only the three data bytes are stored, without any padding.

  - S24_4_RJ_LE: This format stores each 24-bit sample using 32 bits (4 bytes).
    The 24-bit data is stored in the **lower** three bytes, and the highest byte is padding.
    RJ stands for *right justified*, and this may also be called *aligned low*.

  - S24_4_LJ_LE: As the one above, this format stores each 24-bit sample using 32 bits (4 bytes).
    The 24-bit data is stored in the **upper** three bytes, and the lowest byte is padding.
    LJ stands for *left justified*, which may also be called *aligned high*.

  Let's make up three samples and write them as bytes in hex.
  We use little-endian byte order, hence the first byte is the least significant.

  Sample 1: `0xA1, 0xA2, 0xA3`

  Sample 2: `0xB1, 0xB2, 0xB3`

  Sample 3: `0xC1, 0xC2, 0xC3`

  As I24_3_LE: `0xA1, 0xA2, 0xA3, 0xB1, 0xB2, 0xB3, 0xC1, 0xC2, 0xC3`

  As S24_4_RJ_LE: `0xA1, 0xA2, 0xA3, 0x00, 0xB1, 0xB2, 0xB3, 0x00, 0xC1, 0xC2, 0xC3, 0x00`

  As S24_4_LJ_LE: `0x00, 0xA1, 0xA2, 0xA3, 0x00, 0xB1, 0xB2, 0xB3, 0x00, 0xC1, 0xC2, 0xC3`

  Note the extra padding bytes (`0x00`) in S24_4_RJ_LE and S24_4_LJ_LE.
  This scheme means that the samples get an "easier" alignment in memory, while wasting some space.
  In practice, the padded formats are not used very often.

- Why don't I get any sound on MacOS?

  Apps need to be granted access to the microphone in order to record sound from any source.
  Without microphone access, things appear to be running well but only silence is recorded.
  See [Microphone access](./backend_coreaudio.md#microphone-access)

## Filtering

- I only have filters with negative gain, why do I get clipping anyway?
  
  It's not very intuitive, but the peak amplitude can actually increase even though you apply filters that only attenuate. 
  
  The signal is a sum of a large number of frequency components, and in each particular sample some components 
  will add to increase the amplitude while other decrease it. 
  If a filter happens to remove a component that lowers the amplitude in a sample, then the value here will go up. 
  Also all filters affect the phase in a wide range, and this also makes the components sum up to a new waveform that can have higher peaks.
  This is mostly a problem with modern productions that are already a bit clipped to begin with, meaning they have many samples at max amplitude. 
  Try adding a -3 dB Gain filter, that should be enough in most cases.

- When do I need to use an asynchronous resampler?

  The asynchronous resampler must be used when the ratio between the input and output sample rates cannot be expressed as a fixed ratio.
  This is only the case when resampling to adaptively match the rate of two devices with independent clocks, where the ratio drifts a little all the time.
  Note that resampling between the fixed rates 44.1 kHz -> 48 kHz corresponds to a ratio of 160/147, and can be handled by the synchronous resampler.
  This works for any fixed resampling between the standard rates, 44.1 <-> 96 kHz, 88.2 <-> 192 kHz, 88.1 <-> 48 kHz etc.


