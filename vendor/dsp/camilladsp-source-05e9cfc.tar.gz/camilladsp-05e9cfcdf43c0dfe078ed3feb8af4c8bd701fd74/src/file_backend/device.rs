// CamillaDSP - A flexible tool for processing audio
// Copyright (C) 2026 Henrik Enquist
//
// This file is part of CamillaDSP.
//
// CamillaDSP is free software; you can redistribute it and/or modify it
// under the terms of either:
//
// a) the GNU General Public License version 3,
//    or
// b) the Mozilla Public License Version 2.0.
//
// You should have received copies of the GNU General Public License and the
// Mozilla Public License along with this program. If not, see
// <https://www.gnu.org/licenses/> and <https://www.mozilla.org/MPL/2.0/>.

use crate::audiochunk::{AudioChunk, ChunkStats};
use crate::audiodevice::*;
use crate::config;
use crate::config::BinarySampleFormat;
use crate::utils::conversions::{buffer_to_chunk_rawbytes, chunk_to_buffer_rawbytes};
use crate::utils::countertimer;

use std::error::Error;
use std::fs::File;
#[cfg(target_os = "linux")]
use std::fs::OpenOptions;
use std::io::{Write, stdin, stdout};
#[cfg(target_os = "linux")]
use std::os::unix::fs::OpenOptionsExt;
use std::sync::{Arc, Barrier};
use std::thread;
use std::time::Duration;

use parking_lot::{RwLock, RwLockUpgradableReadGuard};

use crate::CommandMessage;
use crate::PrcFmt;
use crate::ProcessingState;
use crate::Res;
use crate::StatusMessage;
#[cfg(all(target_os = "linux", feature = "bluez-backend"))]
use crate::file_backend::bluez as filedevice_bluez;
#[cfg(not(target_os = "linux"))]
use crate::file_backend::filereader::BlockingReader;
#[cfg(target_os = "linux")]
use crate::file_backend::filereader_nonblock::NonBlockingReader;
use crate::utils::resampling::{ChunkResampler, new_resampler, resampler_is_async};
use crate::utils::wavtools::{find_data_in_wav, write_wav_header};
use crate::{CaptureStatus, PlaybackStatus, ProcessingParameters};

pub struct FilePlaybackDevice {
    pub destination: PlaybackDest,
    pub chunksize: usize,
    pub samplerate: usize,
    pub channels: usize,
    pub sample_format: BinarySampleFormat,
    pub wav_header: bool,
}

#[derive(Clone)]
pub enum CaptureSource {
    Filename(String),
    Stdin,
    #[cfg(all(target_os = "linux", feature = "bluez-backend"))]
    BluezDBus(String, String),
}

#[derive(Clone)]
pub enum PlaybackDest {
    Filename(String),
    Stdout,
}

pub struct FileCaptureDevice {
    pub source: CaptureSource,
    pub chunksize: usize,
    pub samplerate: usize,
    pub capture_samplerate: usize,
    pub resampler_config: Option<config::Resampler>,
    pub channels: usize,
    pub sample_format: Option<BinarySampleFormat>,
    pub silence_threshold: PrcFmt,
    pub silence_timeout: PrcFmt,
    pub extra_samples: usize,
    pub skip_bytes: usize,
    pub read_bytes: usize,
    pub stop_on_rate_change: bool,
    pub rate_measure_interval: f32,
}

struct CaptureChannels {
    audio: crossbeam_channel::Sender<AudioMessage>,
    status: crossbeam_channel::Sender<StatusMessage>,
    command: crossbeam_channel::Receiver<CommandMessage>,
}

struct CaptureParams {
    channels: usize,
    sample_format: BinarySampleFormat,
    store_bytes_per_sample: usize,
    extra_bytes: usize,
    buffer_bytes: usize,
    capture_samplerate: usize,
    silence_timeout: PrcFmt,
    silence_threshold: PrcFmt,
    chunksize: usize,
    resampling_ratio: f32,
    read_bytes: usize,
    async_src: bool,
    capture_status: Arc<RwLock<CaptureStatus>>,
    stop_on_rate_change: bool,
    rate_measure_interval: f32,
}
#[derive(Debug)]
pub enum ReadResult {
    Complete(usize),
    Timeout(usize),
    EndOfFile(usize),
}

pub trait Reader {
    fn read(&mut self, data: &mut [u8]) -> Result<ReadResult, Box<dyn Error>>;
}

/// Start a playback thread listening for AudioMessages via a channel.
impl PlaybackDevice for FilePlaybackDevice {
    fn start(
        &mut self,
        channel: crossbeam_channel::Receiver<AudioMessage>,
        barrier: Arc<Barrier>,
        status_channel: crossbeam_channel::Sender<StatusMessage>,
        playback_status: Arc<RwLock<PlaybackStatus>>,
    ) -> Res<Box<thread::JoinHandle<()>>> {
        let destination = self.destination.clone();
        let chunksize = self.chunksize;
        let channels = self.channels;
        let store_bytes_per_sample = self.sample_format.bytes_per_sample();
        let sample_format = self.sample_format;
        let samplerate = self.samplerate;
        let wav_header = self.wav_header;
        let handle = thread::Builder::new()
            .name("FilePlayback".to_string())
            .spawn(move || {
                let file_res: Result<Box<dyn Write>, std::io::Error> = match destination {
                    PlaybackDest::Filename(filename) => {
                        File::create(filename).map(|f| Box::new(f) as Box<dyn Write>)
                    }
                    PlaybackDest::Stdout => Ok(Box::new(stdout())),
                };
                match file_res {
                    Ok(mut file) => {
                        match status_channel.send(StatusMessage::PlaybackReady) {
                            Ok(()) => {}
                            Err(_err) => {}
                        }
                        let mut chunk_stats = ChunkStats {
                            rms: vec![0.0; channels],
                            peak: vec![0.0; channels],
                        };
                        let mut rms_values = Vec::new();
                        let mut peak_values = Vec::new();
                        barrier.wait();
                        debug!("starting playback loop");
                        if wav_header {
                            match write_wav_header(&mut file, channels, sample_format, samplerate) {
                                Ok(()) => debug!("Wrote Wav header"),
                                Err(err) => {
                                    status_channel
                                        .send(StatusMessage::PlaybackError(err.to_string()))
                                        .unwrap_or(());
                                }
                            }
                        }
                        let mut buffer = vec![0u8; chunksize * channels * store_bytes_per_sample];
                        loop {
                            match channel.recv() {
                                Ok(AudioMessage::Audio(chunk)) => {
                                    chunk.update_stats(&mut chunk_stats);
                                    let (valid_bytes, nbr_clipped) = chunk_to_buffer_rawbytes(
                                        chunk,
                                        &mut buffer,
                                        &sample_format,
                                    );
                                    let write_res = file.write_all(&buffer[0..valid_bytes]);
                                    match write_res {
                                        Ok(_) => {}
                                        Err(err) => {
                                            status_channel
                                                .send(StatusMessage::PlaybackError(err.to_string()))
                                                .unwrap_or(());
                                        }
                                    };
                                    crate::update_playback_signal_status(
                                        &playback_status,
                                        &chunk_stats,
                                        &mut rms_values,
                                        &mut peak_values,
                                        nbr_clipped,
                                    );
                                }
                                Ok(AudioMessage::Pause) => {
                                    trace!("Pause message received");
                                }
                                Ok(AudioMessage::EndOfStream) => {
                                    status_channel
                                        .send(StatusMessage::PlaybackDone)
                                        .unwrap_or(());
                                    break;
                                }
                                Err(err) => {
                                    error!("Message channel error: {err}");
                                    status_channel
                                        .send(StatusMessage::PlaybackError(err.to_string()))
                                        .unwrap_or(());
                                    break;
                                }
                            }
                        }
                    }
                    Err(err) => {
                        let send_result =
                            status_channel.send(StatusMessage::PlaybackError(err.to_string()));
                        if send_result.is_err() {
                            error!("Playback error: {err}");
                        }
                        barrier.wait();
                    }
                }
            })
            .unwrap();
        Ok(Box::new(handle))
    }
}

fn nbr_capture_bytes(
    resampler: &Option<ChunkResampler>,
    capture_bytes: usize,
    channels: usize,
    store_bytes_per_sample: usize,
) -> usize {
    if let Some(resampl) = &resampler {
        resampl.resampler.input_frames_next() * channels * store_bytes_per_sample
    } else {
        capture_bytes
    }
}

// Adjust buffer size if needed, and check if capture is done
fn limit_capture_bytes(
    bytes_to_read: usize,
    nbr_bytes_read: usize,
    capture_bytes: usize,
    buf: &mut Vec<u8>,
) -> (usize, bool) {
    let (capture_bytes, done) = if bytes_to_read == 0
        || (bytes_to_read > 0 && (nbr_bytes_read + capture_bytes) <= bytes_to_read)
    {
        (capture_bytes, false)
    } else {
        debug!("Stopping capture, reached read_bytes limit");
        (bytes_to_read - nbr_bytes_read, true)
    };
    if capture_bytes > buf.len() {
        debug!("Capture buffer too small, extending");
        buf.append(&mut vec![0u8; capture_bytes - buf.len()]);
    }
    (capture_bytes, done)
}

fn capture_loop(
    mut file: Box<dyn Reader>,
    params: CaptureParams,
    msg_channels: CaptureChannels,
    mut resampler: Option<ChunkResampler>,
) {
    debug!("preparing captureloop");
    let chunksize_bytes = params.channels * params.chunksize * params.store_bytes_per_sample;
    let bytes_per_frame = params.channels * params.store_bytes_per_sample;
    let mut buf = vec![0u8; params.buffer_bytes];
    let mut bytes_read = 0;
    let mut bytes_to_capture = chunksize_bytes;
    let mut bytes_to_capture_tmp;
    let mut capture_done: bool;
    let mut extra_bytes_left = params.extra_bytes;
    let mut nbr_bytes_read = 0;
    let rate_measure_interval_ms = (1000.0 * params.rate_measure_interval) as u64;
    let mut averager = countertimer::TimeAverage::new();
    let mut watcher_averager = countertimer::TimeAverage::new();
    let mut valuewatcher = countertimer::ValueWatcher::new(
        params.capture_samplerate as f32,
        RATE_CHANGE_THRESHOLD_VALUE,
        RATE_CHANGE_THRESHOLD_COUNT,
    );
    let mut silence_counter = countertimer::SilenceCounter::new(
        params.silence_threshold,
        params.silence_timeout,
        params.capture_samplerate,
        params.chunksize,
    );

    let mut chunk_stats = ChunkStats {
        rms: vec![0.0; params.channels],
        peak: vec![0.0; params.channels],
    };
    let mut rms_values = Vec::new();
    let mut peak_values = Vec::new();
    let mut value_range = 0.0;
    let mut rate_adjust = 0.0;
    let mut state = ProcessingState::Running;
    let mut prev_state = ProcessingState::Running;
    let mut stalled = false;
    loop {
        match msg_channels.command.try_recv() {
            Ok(CommandMessage::Exit) => {
                debug!("Exit message received, sending EndOfStream");
                let msg = AudioMessage::EndOfStream;
                msg_channels.audio.send(msg).unwrap_or(());
                msg_channels
                    .status
                    .send(StatusMessage::CaptureDone)
                    .unwrap_or(());
                break;
            }
            Ok(CommandMessage::SetSpeed { speed }) => {
                rate_adjust = speed;
                if let Some(resampl) = &mut resampler {
                    if params.async_src {
                        if resampl
                            .resampler
                            .set_resample_ratio_relative(speed, true)
                            .is_err()
                        {
                            debug!("Failed to set resampling speed to {speed}");
                        }
                    } else {
                        warn!("Requested rate adjust of synchronous resampler. Ignoring request.");
                    }
                }
            }
            Err(crossbeam_channel::TryRecvError::Empty) => {}
            Err(crossbeam_channel::TryRecvError::Disconnected) => {
                error!("Command channel was closed");
                break;
            }
        };
        bytes_to_capture = nbr_capture_bytes(
            &resampler,
            bytes_to_capture,
            params.channels,
            params.store_bytes_per_sample,
        );
        (bytes_to_capture_tmp, capture_done) = limit_capture_bytes(
            params.read_bytes,
            nbr_bytes_read,
            bytes_to_capture,
            &mut buf,
        );
        let read_res = file.read(&mut buf[0..bytes_to_capture_tmp]);
        match (read_res, capture_done) {
            (Ok(ReadResult::EndOfFile(bytes)), _) | (Ok(ReadResult::Complete(bytes)), true) => {
                bytes_read = bytes;
                nbr_bytes_read += bytes;
                if bytes > 0 {
                    for item in buf.iter_mut().take(bytes_to_capture).skip(bytes) {
                        *item = 0;
                    }
                    debug!("End of file, read only {bytes} of {bytes_to_capture} bytes");
                    let missing =
                        ((bytes_to_capture - bytes) as f32 * params.resampling_ratio) as usize;
                    if extra_bytes_left > missing {
                        bytes_read = bytes_to_capture;
                        extra_bytes_left -= missing;
                    } else {
                        bytes_read += (extra_bytes_left as f32 / params.resampling_ratio) as usize;
                        extra_bytes_left = 0;
                    }
                } else {
                    debug!("Reached end of file");
                    let extra_samples =
                        extra_bytes_left / params.store_bytes_per_sample / params.channels;
                    send_silence(
                        extra_samples,
                        params.channels,
                        params.chunksize,
                        &msg_channels.audio,
                        &mut resampler,
                    );
                    let msg = AudioMessage::EndOfStream;
                    msg_channels.audio.send(msg).unwrap_or(());
                    msg_channels
                        .status
                        .send(StatusMessage::CaptureDone)
                        .unwrap_or(());
                    break;
                }
            }
            (Ok(ReadResult::Timeout(bytes)), _) => {
                bytes_read = bytes;
                nbr_bytes_read += bytes;
                if bytes > 0 {
                    for item in buf.iter_mut().take(bytes_to_capture).skip(bytes) {
                        *item = 0;
                    }
                    debug!("Timed out after reading {bytes} of {bytes_to_capture} bytes");
                    let missing =
                        ((bytes_to_capture - bytes) as f32 * params.resampling_ratio) as usize;
                    if extra_bytes_left > missing {
                        bytes_read = bytes_to_capture;
                        extra_bytes_left -= missing;
                    } else {
                        bytes_read += (extra_bytes_left as f32 / params.resampling_ratio) as usize;
                        extra_bytes_left = 0;
                    }
                } else {
                    trace!("Read timed out");
                    let msg = AudioMessage::Pause;
                    msg_channels.audio.send(msg).unwrap_or(());

                    if !stalled {
                        debug!("Entering stalled state");
                        stalled = true;
                        prev_state = state;
                        state = ProcessingState::Stalled;
                        params.capture_status.write().state = ProcessingState::Stalled;
                    }
                    continue;
                }
            }
            (Ok(ReadResult::Complete(bytes)), false) => {
                trace!("successfully read {bytes} bytes");
                if stalled {
                    debug!("Leaving stalled state, resuming processing");
                    stalled = false;
                    state = prev_state;
                    params.capture_status.write().state = state;
                }
                bytes_read = bytes;
                nbr_bytes_read += bytes;
                averager.add_value(bytes);

                if let Some(capture_status) = params.capture_status.try_upgradable_read() {
                    if averager.larger_than_millis(capture_status.update_interval as u64) {
                        let bytes_per_sec = averager.average();
                        averager.restart();
                        let measured_rate_f = bytes_per_sec
                            / (params.channels * params.store_bytes_per_sample) as f64;
                        trace!("Measured sample rate is {measured_rate_f:.1} Hz");
                        if let Ok(mut capture_status) =
                            RwLockUpgradableReadGuard::try_upgrade(capture_status)
                        {
                            capture_status.measured_samplerate = measured_rate_f as usize;
                            capture_status.signal_range = value_range as f32;
                            capture_status.rate_adjust = rate_adjust as f32;
                            capture_status.state = state;
                        } else {
                            xtrace!("capture status upgrade blocked, skip update");
                        }
                    }
                } else {
                    xtrace!("capture status blocked, skip update");
                }
                watcher_averager.add_value(bytes);
                if watcher_averager.larger_than_millis(rate_measure_interval_ms) {
                    let bytes_per_sec = watcher_averager.average();
                    watcher_averager.restart();
                    let measured_rate_f =
                        bytes_per_sec / (params.channels * params.store_bytes_per_sample) as f64;
                    let changed = valuewatcher.check_value(measured_rate_f as f32);
                    if changed {
                        warn!("sample rate change detected, last rate was {measured_rate_f} Hz");
                        if params.stop_on_rate_change {
                            let msg = AudioMessage::EndOfStream;
                            msg_channels.audio.send(msg).unwrap_or(());
                            msg_channels
                                .status
                                .send(StatusMessage::CaptureFormatChange(measured_rate_f as usize))
                                .unwrap_or(());
                            break;
                        }
                    }
                    trace!("Measured sample rate is {measured_rate_f:.1} Hz");
                }
            }
            (Err(err), _) => {
                debug!("Encountered a read error");
                msg_channels
                    .status
                    .send(StatusMessage::CaptureError(err.to_string()))
                    .unwrap_or(());
            }
        };
        let mut chunk = buffer_to_chunk_rawbytes(
            &buf[0..bytes_to_capture],
            params.channels,
            &params.sample_format,
            bytes_read,
            &params.capture_status.read().used_channels, //channel_mask??
            true,
        );
        chunk.update_stats(&mut chunk_stats);
        crate::update_capture_signal_status(
            &params.capture_status,
            &chunk_stats,
            &mut rms_values,
            &mut peak_values,
        );
        value_range = chunk.maxval - chunk.minval;
        state = silence_counter.update(value_range);
        if state == ProcessingState::Running {
            if let Some(resampl) = &mut resampler {
                resampl.resample_chunk(&mut chunk, params.chunksize, params.channels);
            }
            let msg = AudioMessage::Audio(chunk);
            if msg_channels.audio.send(msg).is_err() {
                info!("Processing thread has already stopped.");
                break;
            }
        } else if state == ProcessingState::Paused {
            let msg = AudioMessage::Pause;
            if msg_channels.audio.send(msg).is_err() {
                info!("Processing thread has already stopped.");
                break;
            }
            sleep_until_next(bytes_per_frame, params.capture_samplerate, bytes_to_capture);
        } else {
            sleep_until_next(bytes_per_frame, params.capture_samplerate, bytes_to_capture);
        }
    }
    params.capture_status.write().state = ProcessingState::Inactive;
}

/// Start a capture thread providing AudioMessages via a channel
impl CaptureDevice for FileCaptureDevice {
    fn start(
        &mut self,
        channel: crossbeam_channel::Sender<AudioMessage>,
        barrier: Arc<Barrier>,
        status_channel: crossbeam_channel::Sender<StatusMessage>,
        command_channel: crossbeam_channel::Receiver<CommandMessage>,
        capture_status: Arc<RwLock<CaptureStatus>>,
        processing_params: Arc<ProcessingParameters>,
    ) -> Res<Box<thread::JoinHandle<()>>> {
        let source = self.source.clone();
        let samplerate = self.samplerate;
        let chunksize = self.chunksize;
        let capture_samplerate = self.capture_samplerate;
        let mut channels = self.channels;
        let mut skip_bytes = self.skip_bytes;
        let mut read_bytes = self.read_bytes;
        let sample_format = match &self.source {
            CaptureSource::Filename(fname) => {
                if let Some(sample_format) = self.sample_format {
                    sample_format
                } else {
                    // No format was given, try to get from the file.
                    // Only works if the file is in wav format.
                    // Also update channels and read & skip bytes.
                    let wav_info = find_data_in_wav(fname)?;
                    skip_bytes = wav_info.data_offset;
                    read_bytes = wav_info.data_length;
                    channels = wav_info.channels;
                    wav_info.sample_format
                }
            }
            _ => self.sample_format.unwrap(),
        };
        let store_bytes_per_sample = sample_format.bytes_per_sample();
        let extra_bytes = self.extra_samples * store_bytes_per_sample * channels;
        let buffer_bytes = 2.0f32.powf(
            (capture_samplerate as f32 / samplerate as f32 * chunksize as f32)
                .log2()
                .ceil(),
        ) as usize
            * 2
            * channels
            * store_bytes_per_sample;
        let resampler_config = self.resampler_config;
        let async_src = resampler_is_async(&resampler_config);
        let silence_timeout = self.silence_timeout;
        let silence_threshold = self.silence_threshold;
        let stop_on_rate_change = self.stop_on_rate_change;
        let rate_measure_interval = self.rate_measure_interval;
        let handle = thread::Builder::new()
            .name("FileCapture".to_string())
            .spawn(move || {
                let resampler = new_resampler(
                    &resampler_config,
                    channels,
                    samplerate,
                    capture_samplerate,
                    chunksize,
                    processing_params.clone(),
                );
                let params = CaptureParams {
                    channels,
                    sample_format,
                    store_bytes_per_sample,
                    extra_bytes,
                    buffer_bytes,
                    silence_threshold,
                    silence_timeout,
                    chunksize,
                    resampling_ratio: samplerate as f32 / capture_samplerate as f32,
                    read_bytes,
                    async_src,
                    capture_status,
                    capture_samplerate,
                    stop_on_rate_change,
                    rate_measure_interval,
                };
                #[cfg(not(target_os = "linux"))]
                let file_res: Result<Box<dyn Reader>, std::io::Error> = match source {
                    CaptureSource::Filename(filename) => File::open(filename)
                        .map(|f| Box::new(BlockingReader::new(f)) as Box<dyn Reader>),
                    CaptureSource::Stdin => Ok(Box::new(BlockingReader::new(stdin()))),
                };
                #[cfg(target_os = "linux")]
                let file_res: Result<Box<dyn Reader>, Box<dyn Error>> = match source {
                    CaptureSource::Filename(filename) => OpenOptions::new()
                        .read(true)
                        .custom_flags(nix::libc::O_NONBLOCK)
                        .open(filename)
                        .map(|f| {
                            Box::new(NonBlockingReader::new(
                                f,
                                2 * 1000 * chunksize as u64 / samplerate as u64,
                            )) as Box<dyn Reader>
                        })
                        .map_err(|e| e.into()),
                    CaptureSource::Stdin => Ok(Box::new(NonBlockingReader::new(
                        stdin(),
                        2 * 1000 * chunksize as u64 / samplerate as u64,
                    ))),
                    #[cfg(all(target_os = "linux", feature = "bluez-backend"))]
                    CaptureSource::BluezDBus(service, path) => {
                        filedevice_bluez::open_bluez_dbus_fd(service, path, chunksize, samplerate)
                            .map(|r| r as Box<dyn Reader>)
                            .map_err(|e| e.into())
                    }
                };
                match file_res {
                    Ok(mut file) => {
                        match status_channel.send(StatusMessage::CaptureReady) {
                            Ok(()) => {}
                            Err(_err) => {}
                        }
                        barrier.wait();
                        let msg_channels = CaptureChannels {
                            audio: channel,
                            status: status_channel,
                            command: command_channel,
                        };
                        if skip_bytes > 0 {
                            debug!("skipping the first {skip_bytes} bytes");
                            let mut tempbuf = vec![0u8; skip_bytes];
                            let _ = file.read(&mut tempbuf);
                        }

                        debug!("starting captureloop");
                        capture_loop(file, params, msg_channels, resampler);
                    }
                    Err(err) => {
                        let send_result =
                            status_channel.send(StatusMessage::CaptureError(err.to_string()));
                        if send_result.is_err() {
                            error!("Capture error: {err}");
                        }
                        barrier.wait();
                    }
                }
            })
            .unwrap();
        Ok(Box::new(handle))
    }
}

fn send_silence(
    samples: usize,
    channels: usize,
    chunksize: usize,
    audio_channel: &crossbeam_channel::Sender<AudioMessage>,
    resampler: &mut Option<ChunkResampler>,
) {
    let mut samples_left = samples;
    while samples_left > 0 {
        let chunk_samples = if samples_left > chunksize {
            chunksize
        } else {
            samples_left
        };
        let waveforms = if let Some(resamp) = resampler {
            resamp.pump_silence(channels, chunksize)
        } else {
            vec![vec![0.0; chunksize]; channels]
        };
        // Take a shortcut and set maxval = minval = 0 because we are anyway very near the end.
        let chunk = AudioChunk::new(waveforms, 0.0, 0.0, chunksize, chunk_samples);
        let msg = AudioMessage::Audio(chunk);
        debug!("Sending extra chunk of {chunk_samples} frames");
        audio_channel.send(msg).unwrap_or(());
        samples_left -= chunk_samples;
    }
}

fn sleep_until_next(bytes_per_frame: usize, samplerate: usize, nbr_bytes: usize) {
    let io_duration =
        Duration::from_millis((1000 * nbr_bytes) as u64 / (bytes_per_frame * samplerate) as u64);
    if io_duration > Duration::from_millis(2) {
        thread::sleep(io_duration - Duration::from_millis(2));
    }
}
