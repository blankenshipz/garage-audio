// CamillaDSP - A flexible tool for processing audio
// Copyright (C) 2026 Henrik Enquist
//
// This file is part of CamillaDSP.
//
// CamillaDSP is free software; you can redistribute it and/or modify it
// under the terms of either:
//
// a) the GNU General Public License version 3,
//    or
// b) the Mozilla Public License Version 2.0.
//
// You should have received copies of the GNU General Public License and the
// Mozilla Public License along with this program. If not, see
// <https://www.gnu.org/licenses/> and <https://www.mozilla.org/MPL/2.0/>.

extern crate alsa;
extern crate nix;
use alsa::pcm::{Frames, HwParams, SwParams};
use std::fmt::Debug;

use crate::Res;
use crate::config;

pub trait DeviceBufferManager {
    // intended for internal use
    fn data(&self) -> &DeviceBufferData;
    fn data_mut(&mut self) -> &mut DeviceBufferData;

    fn apply_start_threshold(&mut self, swp: &SwParams) -> Res<()>;

    // Calculate a power-of-two buffer size that is large enough to accommodate any changes due to resampling,
    // and at least 4 times the minimum period size to avoid random broken pipes.
    fn calculate_buffer_size(&self, min_period: Frames) -> Frames {
        let data = self.data();
        let mut frames_needed = 3.0 * data.chunksize as f32 / data.resampling_ratio;
        if frames_needed < 4.0 * min_period as f32 {
            frames_needed = 4.0 * min_period as f32;
            debug!(
                "Minimum period is {min_period} frames, buffer size is minimum {frames_needed} frames"
            );
        }
        2.0f32.powi(frames_needed.log2().ceil() as i32) as Frames
    }

    // Calculate an alternative buffer size that is 3 multiplied by a power-of-two,
    // and at least 4 times the minimum period size to avoid random broken pipes.
    // This is for some devices that cannot work with the default setting,
    // and when set_buffer_size_near() does not return a working alternative near the requested one.
    // Caused by driver bugs?
    fn calculate_buffer_size_alt(&self, min_period: Frames) -> Frames {
        let data = self.data();
        let mut frames_needed = 3.0 * data.chunksize as f32 / data.resampling_ratio;
        if frames_needed < 4.0 * min_period as f32 {
            frames_needed = 4.0 * min_period as f32;
            debug!(
                "Minimum period is {min_period} frames, alternate buffer size is minimum {frames_needed} frames"
            );
        }
        3 * 2.0f32.powi((frames_needed / 3.0).log2().ceil() as i32) as Frames
    }

    // Calculate a buffer size and apply it to a hwp container. Only for use when opening a device.
    fn apply_buffer_size(&mut self, hwp: &HwParams) -> Res<()> {
        let min_period = hwp.get_period_size_min().unwrap_or(0);
        let buffer_frames = self.calculate_buffer_size(min_period);
        let alt_buffer_frames = self.calculate_buffer_size_alt(min_period);
        let data = self.data_mut();
        debug!("Setting buffer size to {buffer_frames} frames");
        match hwp.set_buffer_size_near(buffer_frames) {
            Ok(frames) => {
                data.bufsize = frames;
            }
            Err(_) => {
                debug!(
                    "Device did not accept a buffer size of {buffer_frames} frames, trying again with {alt_buffer_frames}"
                );
                data.bufsize = hwp.set_buffer_size_near(alt_buffer_frames)?;
            }
        }
        debug!("Device is using a buffer size of {} frames", data.bufsize);
        Ok(())
    }

    // Calculate a period size and apply it to a hwp container. Only for use when opening a device, after setting buffer size.
    fn apply_period_size(&mut self, hwp: &HwParams) -> Res<()> {
        let data = self.data_mut();
        let period_frames = data.bufsize / 8;
        debug!("Setting period size to {period_frames} frames");
        match hwp.set_period_size_near(period_frames, alsa::ValueOr::Nearest) {
            Ok(frames) => {
                data.period = frames;
            }
            Err(_) => {
                let alt_period_frames =
                    3 * 2.0f32.powi((period_frames as f32 / 2.0).log2().ceil() as i32) as Frames;
                debug!(
                    "Device did not accept a period size of {period_frames} frames, trying again with {alt_period_frames}"
                );
                data.period =
                    hwp.set_period_size_near(alt_period_frames, alsa::ValueOr::Nearest)?;
            }
        }
        debug!("Device is using a period size of {} frames", data.period);
        Ok(())
    }

    // Use a fixed period-sized avail_min in threaded mode so device I/O cadence is independent of chunk handoff size.
    fn apply_avail_min(&mut self, swp: &SwParams) -> Res<()> {
        let data = self.data_mut();
        let fixed_io_size = if data.period > 0 { data.period } else { 1 };
        if fixed_io_size > data.bufsize {
            let msg = format!(
                "Trying to set avail_min to {}, must be smaller than or equal to device buffer size of {}",
                fixed_io_size, data.bufsize
            );
            error!("{msg}");
            return Err(config::ConfigError::new(&msg).into());
        }
        data.io_size = fixed_io_size;
        data.avail_min = fixed_io_size;
        swp.set_avail_min(data.avail_min)?;
        Ok(())
    }

    fn update_io_size(&mut self, swp: &SwParams, io_size: Frames) -> Res<()> {
        let data = self.data_mut();
        data.io_size = io_size;
        // must update avail_min
        self.apply_avail_min(swp)?;
        // must update threshold
        self.apply_start_threshold(swp)?;
        Ok(())
    }

    fn frames_to_stall(&self) -> Frames {
        let data = self.data();
        // +1 to make sure the device really stalls
        data.bufsize - data.avail_min + 1
    }

    fn current_delay(&self, avail: Frames) -> Frames;
}

#[derive(Debug)]
pub struct DeviceBufferData {
    bufsize: Frames,
    period: Frames,
    threshold: Frames,
    avail_min: Frames,
    io_size: Frames, /* size of read/write block */
    chunksize: Frames,
    resampling_ratio: f32,
}

impl DeviceBufferData {
    pub fn buffersize(&self) -> Frames {
        self.bufsize
    }

    pub fn periodsize(&self) -> Frames {
        self.period
    }
}

#[derive(Debug)]
pub struct CaptureBufferManager {
    pub data: DeviceBufferData,
}

impl CaptureBufferManager {
    pub fn new(chunksize: Frames, resampling_ratio: f32) -> Self {
        let init_io_size = (chunksize as f32 / resampling_ratio) as Frames;
        CaptureBufferManager {
            data: DeviceBufferData {
                bufsize: 0,
                period: 0,
                threshold: 0,
                avail_min: 0,
                io_size: init_io_size,
                resampling_ratio,
                chunksize,
            },
        }
    }
}

impl DeviceBufferManager for CaptureBufferManager {
    fn data(&self) -> &DeviceBufferData {
        &self.data
    }

    fn data_mut(&mut self) -> &mut DeviceBufferData {
        &mut self.data
    }

    fn apply_start_threshold(&mut self, swp: &SwParams) -> Res<()> {
        // immediate start after pcmdev.prepare
        let threshold = 0;
        swp.set_start_threshold(threshold)?;
        self.data.threshold = threshold;
        Ok(())
    }

    fn current_delay(&self, avail: Frames) -> Frames {
        avail
    }
}

#[derive(Debug)]
pub struct PlaybackBufferManager {
    pub data: DeviceBufferData,
    target_level: Frames,
}

impl PlaybackBufferManager {
    pub fn new(chunksize: Frames, target_level: Frames) -> Self {
        PlaybackBufferManager {
            data: DeviceBufferData {
                bufsize: 0,
                period: 0,
                threshold: 0,
                avail_min: 0,
                io_size: chunksize,
                resampling_ratio: 1.0,
                chunksize,
            },
            target_level,
        }
    }

    pub fn target_level(&self) -> Frames {
        self.target_level
    }
}

impl DeviceBufferManager for PlaybackBufferManager {
    fn data(&self) -> &DeviceBufferData {
        &self.data
    }

    fn data_mut(&mut self) -> &mut DeviceBufferData {
        &mut self.data
    }

    fn apply_start_threshold(&mut self, swp: &SwParams) -> Res<()> {
        // start on first write of any size
        let threshold = 1;
        swp.set_start_threshold(threshold)?;
        self.data.threshold = threshold;
        Ok(())
    }

    fn current_delay(&self, avail: Frames) -> Frames {
        self.data.bufsize - avail
    }
}
