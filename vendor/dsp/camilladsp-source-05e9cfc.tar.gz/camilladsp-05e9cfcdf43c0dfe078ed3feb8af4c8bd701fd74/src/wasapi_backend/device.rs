// CamillaDSP - A flexible tool for processing audio
// Copyright (C) 2026 Henrik Enquist
//
// This file is part of CamillaDSP.
//
// CamillaDSP is free software; you can redistribute it and/or modify it
// under the terms of either:
//
// a) the GNU General Public License version 3,
//    or
// b) the Mozilla Public License Version 2.0.
//
// You should have received copies of the GNU General Public License and the
// Mozilla Public License along with this program. If not, see
// <https://www.gnu.org/licenses/> and <https://www.mozilla.org/MPL/2.0/>.

use crate::audiochunk::ChunkStats;
use crate::audiodevice::*;
use crate::config;
use crate::config::{BinarySampleFormat, ConfigError, WasapiSampleFormat};
use crate::utils::conversions::{buffer_to_chunk_rawbytes, chunk_to_buffer_rawbytes};
use crate::utils::countertimer;
use crate::utils::rate_controller::PIRateController;
use crossbeam_channel::{Receiver, Sender, TryRecvError, TrySendError, bounded, unbounded};
use parking_lot::{RwLock, RwLockUpgradableReadGuard};
use ringbuf::wrap::caching::Caching;
use ringbuf::{HeapRb, traits::*};
use std::collections::VecDeque;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Barrier, Mutex};
use std::thread;
use std::time::Duration;
use wasapi;
use wasapi::DeviceCollection;
use wasapi::StreamMode;

use audio_thread_priority::{
    demote_current_thread_from_real_time, promote_current_thread_to_real_time,
};

use crate::CommandMessage;
use crate::PrcFmt;
use crate::ProcessingParameters;
use crate::ProcessingState;
use crate::Res;
use crate::StatusMessage;
use crate::utils::resampling::{ChunkResampler, new_resampler, resampler_is_async};
use crate::{CaptureStatus, PlaybackStatus};
enum DeviceState {
    Ok(BinarySampleFormat),
    Error(String),
}

#[derive(Clone, Debug)]
pub struct WasapiPlaybackDevice {
    pub devname: Option<String>,
    pub exclusive: bool,
    pub samplerate: usize,
    pub chunksize: usize,
    pub channels: usize,
    pub sample_format: Option<WasapiSampleFormat>,
    pub target_level: usize,
    pub adjust_period: f32,
    pub enable_rate_adjust: bool,
    pub polling: bool,
}

#[derive(Clone, Debug)]
pub struct WasapiCaptureDevice {
    pub devname: Option<String>,
    pub exclusive: bool,
    pub loopback: bool,
    pub samplerate: usize,
    pub resampler_config: Option<config::Resampler>,
    pub capture_samplerate: usize,
    pub chunksize: usize,
    pub channels: usize,
    pub sample_format: Option<WasapiSampleFormat>,
    pub silence_threshold: PrcFmt,
    pub silence_timeout: PrcFmt,
    pub stop_on_rate_change: bool,
    pub rate_measure_interval: f32,
    pub polling: bool,
}

#[derive(Clone, Debug)]
enum DisconnectReason {
    FormatChange,
    Error,
}

pub fn list_device_names(input: bool) -> Vec<(String, String)> {
    let direction = if input {
        wasapi::Direction::Capture
    } else {
        wasapi::Direction::Render
    };
    let _ = wasapi::initialize_mta();
    let enumerator = wasapi::DeviceEnumerator::new();

    let names = enumerator
        .map(|en| {
            en.get_device_collection(&direction)
                .map(|coll| list_device_names_in_collection(&coll).unwrap_or_default())
                .unwrap_or_default()
        })
        .unwrap_or_default();
    names.iter().map(|n| (n.clone(), n.clone())).collect()
}

fn list_device_names_in_collection(collection: &DeviceCollection) -> Res<Vec<String>> {
    let mut names = Vec::new();
    let count = collection.get_nbr_devices()?;
    for n in 0..count {
        let device = collection.get_device_at_index(n)?;
        let name = device.get_friendlyname()?;
        names.push(name);
    }
    Ok(names)
}

fn build_wave_format(
    sample_format: &BinarySampleFormat,
    samplerate: usize,
    channels: usize,
) -> wasapi::WaveFormat {
    match sample_format {
        BinarySampleFormat::S16_LE => {
            wasapi::WaveFormat::new(16, 16, &wasapi::SampleType::Int, samplerate, channels, None)
        }
        BinarySampleFormat::S24_4_LJ_LE => {
            wasapi::WaveFormat::new(32, 24, &wasapi::SampleType::Int, samplerate, channels, None)
        }
        BinarySampleFormat::S24_3_LE => {
            wasapi::WaveFormat::new(24, 24, &wasapi::SampleType::Int, samplerate, channels, None)
        }
        BinarySampleFormat::S32_LE => {
            wasapi::WaveFormat::new(32, 32, &wasapi::SampleType::Int, samplerate, channels, None)
        }
        BinarySampleFormat::F32_LE => wasapi::WaveFormat::new(
            32,
            32,
            &wasapi::SampleType::Float,
            samplerate,
            channels,
            None,
        ),
        _ => unreachable!(),
    }
}

fn get_supported_wave_format(
    audio_client: &wasapi::AudioClient,
    sample_format: &WasapiSampleFormat,
    samplerate: usize,
    channels: usize,
    sharemode: &wasapi::ShareMode,
) -> Res<(wasapi::WaveFormat, BinarySampleFormat)> {
    match sharemode {
        wasapi::ShareMode::Exclusive => match sample_format {
            WasapiSampleFormat::S16 => {
                let wave_format =
                    build_wave_format(&BinarySampleFormat::S16_LE, samplerate, channels);
                Ok((
                    audio_client.is_supported_exclusive_with_quirks(&wave_format)?,
                    BinarySampleFormat::S16_LE,
                ))
            }
            WasapiSampleFormat::S32 => {
                let wave_format =
                    build_wave_format(&BinarySampleFormat::S32_LE, samplerate, channels);
                Ok((
                    audio_client.is_supported_exclusive_with_quirks(&wave_format)?,
                    BinarySampleFormat::S32_LE,
                ))
            }
            WasapiSampleFormat::F32 => {
                let wave_format =
                    build_wave_format(&BinarySampleFormat::F32_LE, samplerate, channels);
                Ok((
                    audio_client.is_supported_exclusive_with_quirks(&wave_format)?,
                    BinarySampleFormat::F32_LE,
                ))
            }
            WasapiSampleFormat::S24 => {
                let wave_format =
                    build_wave_format(&BinarySampleFormat::S24_3_LE, samplerate, channels);
                if let Ok(wavefmt) = audio_client.is_supported_exclusive_with_quirks(&wave_format) {
                    return Ok((wavefmt, BinarySampleFormat::S24_3_LE));
                }
                let wave_format =
                    build_wave_format(&BinarySampleFormat::S24_4_LJ_LE, samplerate, channels);
                Ok((
                    audio_client.is_supported_exclusive_with_quirks(&wave_format)?,
                    BinarySampleFormat::S24_4_LJ_LE,
                ))
            }
        },
        wasapi::ShareMode::Shared => {
            let wave_format = build_wave_format(&BinarySampleFormat::F32_LE, samplerate, channels);
            match audio_client.is_supported(&wave_format, sharemode) {
                Ok(None) => {
                    debug!("Device supports format {wave_format:?}.");
                    Ok((wave_format, BinarySampleFormat::F32_LE))
                }
                Ok(Some(modified)) => {
                    let msg = format!(
                        "Device doesn't support format:\n{wave_format:#?}\nClosest match is:\n{modified:#?}"
                    );
                    Err(ConfigError::new(&msg).into())
                }
                Err(err) => {
                    let msg =
                        format!("Device doesn't support format:\n{wave_format:#?}\nError: {err}");
                    Err(ConfigError::new(&msg).into())
                }
            }
        }
    }
}

fn find_device(
    devname: &Option<String>,
    direction: &wasapi::Direction,
    loopback: bool,
) -> Res<wasapi::Device> {
    let (adjusted_direction, direction_name) = if loopback {
        (
            wasapi::Direction::Render,
            "Render (loopback capture)".to_string(),
        )
    } else {
        (*direction, direction.to_string())
    };
    let enumerator = wasapi::DeviceEnumerator::new()?;
    let device = if let Some(name) = devname {
        let collection = enumerator.get_device_collection(&adjusted_direction)?;
        debug!(
            "Available {} devices: {:?}.",
            direction_name,
            list_device_names_in_collection(&collection)
        );
        collection.get_device_with_name(name)?
    } else {
        enumerator.get_default_device(&adjusted_direction)?
    };
    trace!("Found {direction_name} device {devname:?}.");
    Ok(device)
}

fn get_device_format(
    audio_client: &wasapi::AudioClient,
    samplerate: usize,
    channels: usize,
    requested_format: &Option<WasapiSampleFormat>,
    exclusive: bool,
    direction_name: &str,
) -> Res<(BinarySampleFormat, wasapi::WaveFormat)> {
    let sharemode = match exclusive {
        true => wasapi::ShareMode::Exclusive,
        false => wasapi::ShareMode::Shared,
    };
    let mut temp_format = *requested_format;
    if temp_format.is_none() && !exclusive {
        // no need to test, must be F32
        temp_format = Some(WasapiSampleFormat::F32);
    }
    if let Some(sample_format) = &temp_format {
        let (wave_format, binary_format) = get_supported_wave_format(
            audio_client,
            sample_format,
            samplerate,
            channels,
            &sharemode,
        )?;
        return Ok((binary_format, wave_format));
    }
    debug!("Probing for a supported {direction_name} sample format.");
    for sample_format in [
        WasapiSampleFormat::S32,
        WasapiSampleFormat::S24,
        WasapiSampleFormat::S16,
        WasapiSampleFormat::F32,
    ] {
        trace!("Testing sample format {sample_format:?}.");
        let maybe_wave_format = get_supported_wave_format(
            audio_client,
            &sample_format,
            samplerate,
            channels,
            &sharemode,
        );
        if let Ok((wave_format, binary_format)) = maybe_wave_format {
            debug!("Found supported {direction_name} sample format {sample_format:?}");
            return Ok((binary_format, wave_format));
        }
    }
    let msg = format!(
        "Unable to find a supported sample format for {direction_name} with {channels} channels at {samplerate} Hz."
    );
    Err(ConfigError::new(&msg).into())
}

fn open_playback(
    devname: &Option<String>,
    samplerate: usize,
    channels: usize,
    requested_format: &Option<WasapiSampleFormat>,
    exclusive: bool,
    polling: bool,
) -> Res<(
    wasapi::Device,
    wasapi::AudioClient,
    wasapi::AudioRenderClient,
    Option<wasapi::Handle>,
    BinarySampleFormat,
    wasapi::WaveFormat,
)> {
    let _ = wasapi::initialize_mta();
    let device = find_device(devname, &wasapi::Direction::Render, false)?;
    let mut audio_client = device.get_iaudioclient()?;
    trace!("Got playback iaudioclient.");
    let (binary_format, wave_format) = get_device_format(
        &audio_client,
        samplerate,
        channels,
        requested_format,
        exclusive,
        "Render",
    )?;
    debug!("Opening Wasapi playback device.");
    let (def_time, min_time) = audio_client.get_device_period()?;
    let aligned_time =
        audio_client.calculate_aligned_period_near(def_time, Some(128), &wave_format)?;
    let mode = match (polling, exclusive) {
        (false, false) => StreamMode::EventsShared {
            autoconvert: false,
            buffer_duration_hns: 8 * def_time,
        },
        (false, true) => StreamMode::EventsExclusive {
            period_hns: aligned_time,
        },
        (true, false) => StreamMode::PollingShared {
            autoconvert: false,
            buffer_duration_hns: 8 * def_time,
        },
        (true, true) => StreamMode::PollingExclusive {
            period_hns: aligned_time,
            buffer_duration_hns: 8 * aligned_time,
        },
    };
    debug!("Playback stream mode: {mode:?}");
    audio_client.initialize_client(&wave_format, &wasapi::Direction::Render, &mode)?;
    debug!(
        "Playback default period {def_time}, min period {min_time}, aligned period {aligned_time}."
    );
    debug!("Initialized playback audio client.");
    let handle = if !polling {
        Some(audio_client.set_get_eventhandle()?)
    } else {
        None
    };
    let render_client = audio_client.get_audiorenderclient()?;
    debug!(
        "Opened Wasapi playback device {:?}.",
        device.get_friendlyname()
    );
    Ok((
        device,
        audio_client,
        render_client,
        handle,
        binary_format,
        wave_format,
    ))
}

fn open_capture(
    devname: &Option<String>,
    samplerate: usize,
    channels: usize,
    requested_format: &Option<WasapiSampleFormat>,
    exclusive: bool,
    polling: bool,
    loopback: bool,
) -> Res<(
    wasapi::Device,
    wasapi::AudioClient,
    wasapi::AudioCaptureClient,
    Option<wasapi::Handle>,
    BinarySampleFormat,
    wasapi::WaveFormat,
)> {
    let _ = wasapi::initialize_mta();
    let device = find_device(devname, &wasapi::Direction::Capture, loopback)?;
    let mut audio_client = device.get_iaudioclient()?;
    trace!("Got capture iaudioclient.");
    let (binary_format, wave_format) = get_device_format(
        &audio_client,
        samplerate,
        channels,
        requested_format,
        exclusive,
        "Capture",
    )?;
    let (def_time, min_time) = audio_client.get_device_period()?;
    debug!("Capture default period {def_time}, min period {min_time}.");
    let aligned_time =
        audio_client.calculate_aligned_period_near(def_time, Some(128), &wave_format)?;
    let mode = match (polling, exclusive) {
        (false, false) => StreamMode::EventsShared {
            autoconvert: false,
            buffer_duration_hns: 8 * def_time,
        },
        (false, true) => StreamMode::EventsExclusive {
            period_hns: aligned_time,
        },
        (true, false) => StreamMode::PollingShared {
            autoconvert: false,
            buffer_duration_hns: 8 * def_time,
        },
        (true, true) => StreamMode::PollingExclusive {
            period_hns: aligned_time,
            buffer_duration_hns: 8 * aligned_time,
        },
    };
    debug!("Capture stream mode: {mode:?}");
    audio_client.initialize_client(&wave_format, &wasapi::Direction::Capture, &mode)?;
    debug!("Initialized capture audio client.");
    let handle = if !polling {
        Some(audio_client.set_get_eventhandle()?)
    } else {
        None
    };
    trace!("Capture got event handle.");
    let capture_client = audio_client.get_audiocaptureclient()?;
    debug!(
        "Opened Wasapi capture device {:?}.",
        device.get_friendlyname()
    );
    Ok((
        device,
        audio_client,
        capture_client,
        handle,
        binary_format,
        wave_format,
    ))
}

struct PlaybackSync {
    rx_play: Receiver<PlaybackDeviceMessage>,
    tx_cb: Sender<DisconnectReason>,
    bufferfill: Arc<Mutex<countertimer::DeviceBufferEstimator>>,
}

enum PlaybackDeviceMessage {
    Data(usize),
    Stop,
}

// Playback loop, play samples received from channel
#[allow(clippy::too_many_arguments)]
fn playback_loop(
    audio_client: wasapi::AudioClient,
    render_client: wasapi::AudioRenderClient,
    handle: Option<wasapi::Handle>,
    blockalign: usize,
    chunksize: usize,
    sync: PlaybackSync,
    mut ringbuffer: Caching<Arc<HeapRb<u8>>, false, true>,
    target_level: usize,
) -> Res<()> {
    let mut buffer_free_frame_count = audio_client.get_buffer_size()?;
    let mut sample_queue: VecDeque<u8> = VecDeque::with_capacity(
        4 * blockalign * (chunksize + 2 * buffer_free_frame_count as usize)
            + target_level * blockalign,
    );

    let tx_cb = sync.tx_cb;
    let mut callbacks = wasapi::EventCallbacks::new();
    callbacks.set_disconnected_callback(move |reason| {
        debug!("Disconnected, reason: {reason:?}.");
        let simplereason = match reason {
            wasapi::DisconnectReason::FormatChanged => DisconnectReason::FormatChange,
            _ => DisconnectReason::Error,
        };
        tx_cb.send(simplereason).unwrap_or(());
    });

    let sessioncontrol = audio_client.get_audiosessioncontrol()?;
    let _notifications = sessioncontrol.register_session_notification(callbacks)?;

    let mut waited_millis = 0;
    trace!("Waiting for data to start playback, will time out after one second.");
    while sync.rx_play.len() < 2 && waited_millis < 1000 {
        thread::sleep(Duration::from_millis(10));
        waited_millis += 10;
    }
    debug!("Waited for data for {waited_millis} ms.");

    // Raise priority
    let _thread_handle = match promote_current_thread_to_real_time(0, 1) {
        Ok(h) => {
            debug!("Playback inner thread has real-time priority.");
            Some(h)
        }
        Err(err) => {
            warn!("Playback inner thread could not get real time priority, error: {err}.");
            None
        }
    };

    audio_client.start_stream()?;
    let mut running = false;
    let mut starting = true;
    let (device_period_hns, _) = audio_client.get_device_period()?;
    // set poll delay to one device period, may be shorter than needed
    let poll_delay = std::time::Duration::from_micros(device_period_hns as u64 / 10);
    if handle.is_none() {
        debug!(
            "Playback uses polling mode, delay is {} us.",
            poll_delay.as_micros()
        );
    }
    loop {
        buffer_free_frame_count = audio_client.get_available_space_in_frames()?;
        trace!("Playback, new buffer frame count {buffer_free_frame_count}.");

        while sample_queue.len() < (blockalign * buffer_free_frame_count as usize) {
            trace!("Playback loop needs more samples, reading from channel.");
            match sync.rx_play.try_recv() {
                Ok(PlaybackDeviceMessage::Data(bytes)) => {
                    trace!("Playback received chunk.");
                    if !running {
                        running = true;
                        if starting {
                            starting = false;
                        } else {
                            warn!("Restarting playback after buffer underrun.");
                        }
                        debug!(
                            "Playback, inserting {target_level} silent frames to reach target delay."
                        );
                        for _ in 0..(blockalign * target_level) {
                            sample_queue.push_back(0);
                        }
                    }
                    for element in ringbuffer.pop_iter().take(bytes) {
                        sample_queue.push_back(element);
                    }
                }
                Ok(PlaybackDeviceMessage::Stop) => {
                    debug!("Stopping inner playback loop.");
                    audio_client.stop_stream()?;
                    return Ok(());
                }
                Err(TryRecvError::Empty) => {
                    for _ in
                        0..((blockalign * buffer_free_frame_count as usize) - sample_queue.len())
                    {
                        sample_queue.push_back(0);
                    }
                    if running {
                        running = false;
                        warn!("Playback interrupted, no data available.");
                    }
                }
                Err(TryRecvError::Disconnected) => {
                    error!("Playback, channel is closed.");
                    return Err(DeviceError::new("Playback data channel closed.").into());
                }
            }
        }
        render_client.write_to_device_from_deque(
            buffer_free_frame_count as usize,
            &mut sample_queue,
            None,
        )?;
        let curr_buffer_fill = sample_queue.len() / blockalign + sync.rx_play.len() * chunksize;
        if let Ok(mut estimator) = sync.bufferfill.try_lock() {
            estimator.add(curr_buffer_fill)
        }
        //println!("{} bef",prev_inst.elapsed().as_micros());
        if let Some(ref h) = handle {
            if h.wait_for_event(1000).is_err() {
                error!("Error on playback, stopping stream");
                audio_client.stop_stream()?;
                return Err(DeviceError::new("Error on playback").into());
            }
        } else {
            thread::sleep(poll_delay);
        }
    }
}

struct CaptureChannels {
    pub tx_filled: Sender<(u64, usize)>,
    pub ringbuf: Caching<Arc<HeapRb<u8>>, true, false>,
}

// Capture loop, capture samples and send in chunks of "chunksize" frames to channel
#[allow(clippy::too_many_arguments)]
fn capture_loop(
    audio_client: wasapi::AudioClient,
    capture_client: wasapi::AudioCaptureClient,
    handle: Option<wasapi::Handle>,
    mut channels: CaptureChannels,
    tx_disconnectreason: Sender<DisconnectReason>,
    blockalign: usize,
    stop_signal: Arc<AtomicBool>,
) -> Res<()> {
    let mut chunk_nbr: u64 = 0;

    let mut callbacks = wasapi::EventCallbacks::new();
    callbacks.set_disconnected_callback(move |reason| {
        debug!("Capture disconnected, reason: {reason:?}.");
        let simplereason = match reason {
            wasapi::DisconnectReason::FormatChanged => DisconnectReason::FormatChange,
            _ => DisconnectReason::Error,
        };
        tx_disconnectreason.send(simplereason).unwrap_or(());
    });

    let sessioncontrol = audio_client.get_audiosessioncontrol()?;
    let _notifications = sessioncontrol.register_session_notification(callbacks)?;

    let mut inactive = false;

    let mut data = vec![0u8; 8 * blockalign * 1024];
    let (default_delay_hns, _) = audio_client.get_device_period()?;
    // set poll delay to one device period, may be shorter than needed
    let poll_delay = std::time::Duration::from_micros(default_delay_hns as u64 / 10);
    if handle.is_none() {
        debug!(
            "Capture uses polling mode, delay is {} us.",
            poll_delay.as_micros()
        );
    }
    let mut no_frames_counter = 0;

    // Raise priority
    let _thread_handle = match promote_current_thread_to_real_time(0, 1) {
        Ok(h) => {
            debug!("Capture inner thread has real-time priority.");
            Some(h)
        }
        Err(err) => {
            warn!("Capture inner thread could not get real time priority, error: {err}.");
            None
        }
    };
    trace!("Starting capture stream.");
    audio_client.start_stream()?;
    trace!("Started capture stream.");
    loop {
        trace!("Capturing.");
        if stop_signal.load(Ordering::Relaxed) {
            debug!("Stopping inner capture loop on request.");
            audio_client.stop_stream()?;
            return Ok(());
        }
        if let Some(ref h) = handle {
            if h.wait_for_event(250).is_err() {
                debug!("Capture, timeout on event.");
                if !inactive {
                    warn!("Capture, no data received, pausing stream.");
                    inactive = true;
                }
                match channels.tx_filled.try_send((chunk_nbr, 0)) {
                    Ok(()) | Err(TrySendError::Full(_)) => {}
                    Err(TrySendError::Disconnected(_)) => {
                        error!("Capture, error sending data, channel disconnected.");
                        audio_client.stop_stream()?;
                        return Err(DeviceError::new("Capture, channel disconnected.").into());
                    }
                }
                chunk_nbr += 1;
                continue;
            }
        } else {
            thread::sleep(poll_delay);
            let frames_ready = audio_client.get_current_padding()?;
            trace!("Capture, nbr frames ready after sleep: {frames_ready}.");
            if frames_ready > 0 {
                no_frames_counter = 0;
            } else {
                no_frames_counter += 1;
                if no_frames_counter > 10 {
                    debug!(
                        "Capture, no new frames from device in the last {no_frames_counter} iterations."
                    );
                    if !inactive {
                        warn!("Capture, no data received, pausing stream.");
                        inactive = true;
                    }
                    match channels.tx_filled.try_send((chunk_nbr, 0)) {
                        Ok(()) | Err(TrySendError::Full(_)) => {}
                        Err(TrySendError::Disconnected(_)) => {
                            error!("Capture, error sending data, channel disconnected.");
                            audio_client.stop_stream()?;
                            return Err(DeviceError::new("Capture, channel disconnected.").into());
                        }
                    }
                    chunk_nbr += 1;
                    continue;
                }
            }
        }

        if inactive {
            info!("Capture, new data received, resuming stream.");
            inactive = false;
        }
        let mut available_frames = match capture_client.get_next_packet_size()? {
            // shared mode, gives next package size for both polling end event modes
            Some(frames) => frames,
            // exclusive mode, polling and event modes need separate handling
            None => {
                if handle.is_some() {
                    // event driven mode, always gives a full buffer
                    audio_client.get_buffer_size()?
                } else {
                    // polling mode, padding gives a snapshot, may have increased once we get the buffer
                    audio_client.get_current_padding()?
                }
            }
        };

        trace!("Capture, available frames from dev: {available_frames}.");

        // If no available frames, just skip the rest of this loop iteration
        if available_frames > 0 {
            // loop to make sure we have read all available packets
            let mut nbr_bytes = 0;
            loop {
                let (nbr_frames_read, bufferinfo) =
                    capture_client.read_from_device(&mut data[nbr_bytes..])?;
                if nbr_frames_read < available_frames {
                    debug!("Expected {available_frames} frames, got {nbr_frames_read}.");
                }
                let nbr_bytes_loop = nbr_frames_read as usize * blockalign;
                if bufferinfo.flags.silent {
                    debug!("Captured a buffer marked as silent.");
                    data.iter_mut()
                        .skip(nbr_bytes)
                        .take(nbr_bytes_loop)
                        .for_each(|val| *val = 0);
                }
                nbr_bytes += nbr_bytes_loop;
                if audio_client.get_sharemode() == Some(wasapi::ShareMode::Exclusive)
                    && audio_client.get_timing_mode() == Some(wasapi::TimingMode::Events)
                {
                    break;
                }

                // Shared mode, is there another packet available?
                if let Some(next_frames) = capture_client.get_next_packet_size()? {
                    if next_frames == 0 {
                        break;
                    } else {
                        trace!("Capture, additional packet available with {next_frames} frames.");
                        available_frames = next_frames;
                    }
                }
                // Exclusive with polling, are there more frames in the buffer?
                else if let Ok(padding) = audio_client.get_current_padding() {
                    if padding == 0 {
                        break;
                    } else {
                        trace!(
                            "Capture, more frames available, current padding is {padding} frames."
                        );
                        available_frames = padding;
                    }
                }
            }

            // Disabled since VB-Audio Cable gives this all the time
            // even though there seems to be no problem. Buggy?
            //if flags.data_discontinuity {
            //    warn!("Capture device reported a buffer overrun");

            let pushed_bytes = channels.ringbuf.push_slice(&data[0..nbr_bytes]);
            if pushed_bytes < nbr_bytes {
                debug!(
                    "Capture ring buffer is full, dropped {} out of {} bytes",
                    nbr_bytes - pushed_bytes,
                    nbr_bytes
                );
            }
            match channels.tx_filled.try_send((chunk_nbr, pushed_bytes)) {
                Ok(()) => {}
                Err(TrySendError::Full((nbr, length))) => {
                    warn!(
                        "Capture, notification channel full, dropping chunk nbr {nbr} with len {length}."
                    );
                }
                Err(TrySendError::Disconnected(_)) => {
                    error!("Capture, error sending data, channel disconnected.");
                    audio_client.stop_stream()?;
                    return Err(DeviceError::new("Capture, channel disconnected.").into());
                }
            }
            chunk_nbr += 1;
        }
    }
}

/// Start a playback thread listening for AudioMessages via a channel.
impl PlaybackDevice for WasapiPlaybackDevice {
    fn start(
        &mut self,
        channel: crossbeam_channel::Receiver<AudioMessage>,
        barrier: Arc<Barrier>,
        status_channel: crossbeam_channel::Sender<StatusMessage>,
        playback_status: Arc<RwLock<PlaybackStatus>>,
    ) -> Res<Box<thread::JoinHandle<()>>> {
        let devname = self.devname.clone();
        let exclusive = self.exclusive;
        let polling = self.polling;
        let samplerate = self.samplerate;
        let chunksize = self.chunksize;
        let channels = self.channels;
        let target_level = if self.target_level > 0 {
            self.target_level
        } else {
            self.chunksize
        };
        let adjust_period = self.adjust_period;
        let adjust = self.adjust_period > 0.0 && self.enable_rate_adjust;
        let sample_format = self.sample_format;
        let handle = thread::Builder::new()
            .name("WasapiPlayback".to_string())
            .spawn(move || {
                // Devices typically request around 1000 frames per buffer, set a reasonable capacity for the channel
                let channel_capacity = 8 * 1024 / chunksize + 3;
                debug!(
                    "Using a playback channel capacity of {channel_capacity} chunks."
                );
                let (tx_dev, rx_dev) = bounded(channel_capacity);
                let (tx_state_dev, rx_state_dev) = bounded(0);
                let (tx_disconnectreason, rx_disconnectreason) = unbounded();
                let buffer_fill = Arc::new(Mutex::new(countertimer::DeviceBufferEstimator::new(samplerate)));
                let buffer_fill_clone = buffer_fill.clone();
                let mut buffer_avg = countertimer::Averager::new();
                let mut timer = countertimer::Stopwatch::new();
                let mut chunk_stats = ChunkStats {
                    rms: vec![0.0; channels],
                    peak: vec![0.0; channels],
                };
                let mut rms_values = Vec::new();
                let mut peak_values = Vec::new();

                let mut rate_controller = PIRateController::new_with_default_gains(samplerate, adjust_period as f64, target_level);

                trace!("Build output stream.");
                let mut conversion_result;

                // Use 4 bytes per sample (the maximum) for the ring buffer
                let ringbuffer = HeapRb::<u8>::new(channels * 4 * ( 2 * chunksize + 2048 ));
                let (mut device_producer, device_consumer) = ringbuffer.split();

                // wasapi device loop
                let innerhandle = thread::Builder::new()
                    .name("WasapiPlaybackInner".to_string())
                    .spawn(move || {
                        let (_device, audio_client, render_client, handle, _binary_format, wave_format) =
                            match open_playback(
                                &devname,
                                samplerate,
                                channels,
                                &sample_format,
                                exclusive,
                                polling,
                            ) {
                                Ok(result) => {
                                    tx_state_dev.send(DeviceState::Ok(result.4)).unwrap_or(());
                                    result
                                }
                                Err(err) => {
                                    let msg = format!("Playback error: {err}");
                                    tx_state_dev.send(DeviceState::Error(msg)).unwrap_or(());
                                    return;
                                }
                            };
                        let blockalign = wave_format.get_blockalign();
                        let sync = PlaybackSync {
                            rx_play: rx_dev,
                            tx_cb: tx_disconnectreason,
                            bufferfill: buffer_fill_clone,
                        };
                        let result = playback_loop(
                            audio_client,
                            render_client,
                            handle,
                            blockalign as usize,
                            chunksize,
                            sync,
                            device_consumer,
                            target_level,
                        );
                        if let Err(err) = result {
                            let msg = format!("Playback failed with error: {err}");
                            //error!("{}", msg);
                            tx_state_dev.send(DeviceState::Error(msg)).unwrap_or(());
                        }
                    })
                    .unwrap();
                let binary_format = match rx_state_dev.recv() {
                    Ok(DeviceState::Ok(fmt)) => fmt,
                    Ok(DeviceState::Error(err)) => {
                        status_channel
                            .send(StatusMessage::PlaybackError(err))
                            .unwrap_or(());
                        barrier.wait();
                        return;
                    }
                    Err(err) => {
                        status_channel
                            .send(StatusMessage::PlaybackError(err.to_string()))
                            .unwrap_or(());
                        barrier.wait();
                        return;
                    }
                };

                match status_channel.send(StatusMessage::PlaybackReady) {
                    Ok(()) => {}
                    Err(_err) => {}
                }
                debug!("Playback device ready and waiting.");
                barrier.wait();
                let thread_handle = match promote_current_thread_to_real_time(0, 1) {
                    Ok(h) => {
                        debug!("Playback outer thread has real-time priority.");
                        Some(h)
                    }
                    Err(err) => {
                        warn!(
                            "Playback outer thread could not get real time priority, error: {err}."
                        );
                        None
                    }
                };

                let mut buf =
                    vec![
                        0u8;
                        channels * chunksize * binary_format.bytes_per_sample()
                    ];

                debug!("Playback device starts now!");
                loop {
                    match rx_state_dev.try_recv() {
                        Ok(DeviceState::Ok(_)) => {}
                        Ok(DeviceState::Error(err)) => {
                            send_error_or_playbackformatchange(
                                &status_channel,
                                &rx_disconnectreason,
                                err,
                            );
                            break;
                        }
                        Err(TryRecvError::Empty) => {}
                        Err(TryRecvError::Disconnected) => {
                            send_error_or_playbackformatchange(
                                &status_channel,
                                &rx_disconnectreason,
                                "Inner playback thread has exited".to_string(),
                            );
                            break;
                        }
                    }
                    match channel.recv() {
                        Ok(AudioMessage::Audio(chunk)) => {
                            let estimated_buffer_fill = buffer_fill.try_lock().map(|b| b.estimate() as f64).unwrap_or_default();
                            buffer_avg.add_value(estimated_buffer_fill + (channel.len() * chunksize) as f64);

                            if adjust
                                && timer.larger_than_millis((1000.0 * adjust_period) as u64)
                                && let Some(av_delay) = buffer_avg.average()
                            {
                                let speed = rate_controller.next(av_delay);
                                timer.restart();
                                buffer_avg.restart();
                                debug!(
                                    "Playback, current buffer level {:.1}, set capture rate to {:.4}%.",
                                    av_delay,
                                    100.0 * speed
                                );
                                status_channel
                                    .send(StatusMessage::SetSpeed(speed))
                                    .unwrap_or(());
                                if let Some(mut playback_status) = playback_status.try_write() {
                                    playback_status.buffer_level = av_delay as usize;
                                } else {
                                    xtrace!("Playback status blocked, skip buffer level update.");
                                }
                            }
                            chunk.update_stats(&mut chunk_stats);
                            conversion_result =
                                chunk_to_buffer_rawbytes(chunk, &mut buf, &binary_format);
                            crate::update_playback_signal_status(
                                &playback_status,
                                &chunk_stats,
                                &mut rms_values,
                                &mut peak_values,
                                conversion_result.1,
                            );
                            // Wait for enough space in the ring buffer before pushing.
                            // This is essential when the capture side is not rate-limited
                            // (e.g. signal generator): without this wait the data would
                            // arrive far faster than the playback callback can drain it
                            // and most of it would be dropped.  The sleep duration is
                            // based on the time it takes to play back one chunksize.
                            let bytes_to_write = conversion_result.0;
                            let sleep_duration = std::time::Duration::from_micros(
                                (1_000_000 * chunksize / samplerate / 2) as u64
                            );
                            let max_retries = 8;
                            for _ in 0..max_retries {
                                if device_producer.vacant_len() >= bytes_to_write {
                                    break;
                                }
                                std::thread::sleep(sleep_duration);
                            }
                            if device_producer.vacant_len() >= bytes_to_write {
                                device_producer.push_slice(&buf[0..bytes_to_write]);
                            } else {
                                debug!(
                                    "Playback ring buffer is full, dropped chunk of {bytes_to_write} bytes",
                                );
                                continue;
                            }
                            match tx_dev.send(PlaybackDeviceMessage::Data(bytes_to_write)) {
                                Ok(_) => {}
                                Err(err) => {
                                    error!("Playback device channel error: {err}.");
                                    send_error_or_playbackformatchange(
                                        &status_channel,
                                        &rx_disconnectreason,
                                        err.to_string(),
                                    );
                                    break;
                                }
                            }
                        }
                        Ok(AudioMessage::Pause) => {
                            trace!("Playback, pause message received.");
                        }
                        Ok(AudioMessage::EndOfStream) => {
                            status_channel
                                .send(StatusMessage::PlaybackDone)
                                .unwrap_or(());
                            break;
                        }
                        Err(err) => {
                            error!("Playback, message channel error: {err}.");
                            send_error_or_playbackformatchange(
                                &status_channel,
                                &rx_disconnectreason,
                                err.to_string(),
                            );
                            break;
                        }
                    }
                }
                if let Some(h) = thread_handle {
                    match demote_current_thread_from_real_time(h) {
                        Ok(_) => {
                            debug!("Playback outer thread returned to normal priority.")
                        }
                        Err(_) => {
                            warn!("Could not bring the outer playback thread back to normal priority.")
                        }
                    };
                }
                match tx_dev.send(PlaybackDeviceMessage::Stop) {
                    Ok(_) => {
                        debug!("Wait for inner playback thread to exit.");
                        innerhandle.join().unwrap_or(());
                    }
                    Err(_) => {
                        warn!("Inner playback thread already stopped.")
                    }
                }
            })?;
        Ok(Box::new(handle))
    }
}

fn check_for_format_change(rx: &Receiver<DisconnectReason>) -> bool {
    loop {
        match rx.try_recv() {
            Ok(DisconnectReason::Error) => {}
            Ok(DisconnectReason::FormatChange) => {
                return true;
            }
            Err(TryRecvError::Empty) => {
                return false;
            }
            Err(TryRecvError::Disconnected) => {
                return false;
            }
        }
    }
}

fn send_error_or_playbackformatchange(
    tx: &crossbeam_channel::Sender<StatusMessage>,
    rx: &Receiver<DisconnectReason>,
    err: String,
) {
    if check_for_format_change(rx) {
        debug!("Send PlaybackFormatChange.");
        tx.send(StatusMessage::PlaybackFormatChange(0))
            .unwrap_or(());
    } else {
        debug!("Send PlaybackError.");
        tx.send(StatusMessage::PlaybackError(err)).unwrap_or(());
    }
}

fn send_error_or_captureformatchange(
    tx: &crossbeam_channel::Sender<StatusMessage>,
    rx: &Receiver<DisconnectReason>,
    err: String,
) {
    if check_for_format_change(rx) {
        debug!("Send CaptureFormatChange.");
        tx.send(StatusMessage::CaptureFormatChange(0)).unwrap_or(());
    } else {
        debug!("Send CaptureError.");
        tx.send(StatusMessage::CaptureError(err)).unwrap_or(());
    }
}

fn nbr_capture_frames(resampler: &Option<ChunkResampler>, capture_frames: usize) -> usize {
    if let Some(resampl) = &resampler {
        #[cfg(feature = "debug")]
        trace!(
            "Resampler needs {} frames.",
            resampl.resampler.input_frames_next()
        );
        resampl.resampler.input_frames_next()
    } else {
        capture_frames
    }
}

/// Start a capture thread providing AudioMessages via a channel
impl CaptureDevice for WasapiCaptureDevice {
    fn start(
        &mut self,
        channel: crossbeam_channel::Sender<AudioMessage>,
        barrier: Arc<Barrier>,
        status_channel: crossbeam_channel::Sender<StatusMessage>,
        command_channel: crossbeam_channel::Receiver<CommandMessage>,
        capture_status: Arc<RwLock<CaptureStatus>>,
        processing_params: Arc<ProcessingParameters>,
    ) -> Res<Box<thread::JoinHandle<()>>> {
        let exclusive = self.exclusive;
        let polling = self.polling;
        let loopback = self.loopback;
        let devname = self.devname.clone();
        let samplerate = self.samplerate;
        let capture_samplerate = self.capture_samplerate;
        let chunksize = self.chunksize;
        let channels = self.channels;
        let sample_format = self.sample_format;
        let resampler_conf = self.resampler_config;
        let async_src = resampler_is_async(&resampler_conf);
        let silence_timeout = self.silence_timeout;
        let silence_threshold = self.silence_threshold;
        let stop_on_rate_change = self.stop_on_rate_change;
        let rate_measure_interval = (1000.0 * self.rate_measure_interval) as u64;
        let handle = thread::Builder::new()
            .name("WasapiCapture".to_string())
            .spawn(move || {
                let mut resampler = new_resampler(
                        &resampler_conf,
                        channels,
                        samplerate,
                        capture_samplerate,
                        chunksize,
                    processing_params.clone(),
                );
                // Devices typically give around 1000 frames per buffer, set a reasonable capacity for the channel
                let channel_capacity = if let Some(resamp) = &resampler {
                    let max_input_frames = resamp.resampler.input_frames_max();
                    32*(chunksize + max_input_frames)/1024 + 10
                } else {
                    32*chunksize/1024 + 10
                };
                debug!("Using a capture channel capacity of {channel_capacity} buffers.");
                let (tx_dev, rx_dev) = bounded(channel_capacity);

                let (tx_state_dev, rx_state_dev) = bounded(0);
                let (tx_start_inner, rx_start_inner) = bounded(0);
                let (tx_disconnectreason, rx_disconnectreason) = unbounded();

                // Use 4 bytes per sample (the maximum) for the ring buffer
                let buffer_capacity_frames = if let Some(resamp) = &resampler {
                    resamp.resampler.input_frames_max()
                } else {
                    chunksize
                };
                let ringbuffer =
                    HeapRb::<u8>::new(channels * 4 * (2 * buffer_capacity_frames + 2048));
                let (device_producer, mut device_consumer) = ringbuffer.split();

                trace!("Build input stream.");
                // wasapi device loop
                let stop_signal = Arc::new(AtomicBool::new(false));
                let stop_signal_inner = stop_signal.clone();
                let innerhandle = thread::Builder::new()
                    .name("WasapiCaptureInner".to_string())
                    .spawn(move || {
                        let (_device, audio_client, capture_client, handle, _binary_format, wave_format) =
                        match open_capture(&devname, capture_samplerate, channels, &sample_format, exclusive, polling, loopback) {
                            Ok(result) => {
                                tx_state_dev.send(DeviceState::Ok(result.4)).unwrap_or(());
                                result
                            },
                            Err(err) => {
                                error!("Failed to open capture device, error: {err}");
                                let msg = format!("Capture error: {err}");
                                tx_state_dev.send(DeviceState::Error(msg)).unwrap_or(());
                                return;
                            }
                        };
                        let blockalign = wave_format.get_blockalign();
                        let channels =  CaptureChannels {
                            tx_filled: tx_dev,
                            ringbuf: device_producer,
                        };
                        let _rx_res = rx_start_inner.recv();
                        let result = capture_loop(audio_client, capture_client, handle, channels, tx_disconnectreason, blockalign as usize, stop_signal_inner);
                        if let Err(err) = result {
                            let msg = format!("Capture failed with error: {err}");
                            //error!("{}", msg);
                            tx_state_dev.send(DeviceState::Error(msg)).unwrap_or(());
                        }
                    }).unwrap();
                let binary_format = match rx_state_dev.recv() {
                    Ok(DeviceState::Ok(fmt)) => fmt,
                    Ok(DeviceState::Error(err)) => {
                        channel.send(AudioMessage::EndOfStream).unwrap_or(());
                        status_channel.send(StatusMessage::CaptureError(err)).unwrap_or(());
                        barrier.wait();
                        return;
                     },
                    Err(err) => {
                        channel.send(AudioMessage::EndOfStream).unwrap_or(());
                        status_channel.send(StatusMessage::CaptureError(err.to_string() )).unwrap_or(());
                        barrier.wait();
                        return;
                    },
                };
                let bytes_per_sample = binary_format.bytes_per_sample();

                let mut capture_frames = chunksize;
                let mut averager = countertimer::TimeAverage::new();
                let mut watcher_averager = countertimer::TimeAverage::new();
                let mut valuewatcher = countertimer::ValueWatcher::new(capture_samplerate as f32, RATE_CHANGE_THRESHOLD_VALUE, RATE_CHANGE_THRESHOLD_COUNT);
                let mut value_range = 0.0;
                let mut chunk_stats = ChunkStats{rms: vec![0.0; channels], peak: vec![0.0; channels]};
                let mut rms_values = Vec::new();
                let mut peak_values = Vec::new();
                let mut rate_adjust = 0.0;
                let mut silence_counter = countertimer::SilenceCounter::new(silence_threshold, silence_timeout, capture_samplerate, chunksize);
                let mut state = ProcessingState::Running;
                let mut saved_state = state;
                let blockalign = bytes_per_sample*channels;
                // TODO check if this ever needs to be resized
                let mut data_buffer = vec![0u8; 4 * blockalign * capture_frames];
                let mut expected_chunk_nbr = 0;
                debug!("Capture device ready and waiting.");
                match status_channel.send(StatusMessage::CaptureReady) {
                    Ok(()) => {}
                    Err(_err) => {}
                }
                barrier.wait();
                let thread_handle = match promote_current_thread_to_real_time(0, 1) {
                    Ok(h) => {
                        debug!("Capture outer thread has real-time priority.");
                        Some(h)
                    }
                    Err(err) => {
                        warn!(
                            "Capture outer thread could not get real time priority, error: {err}."
                        );
                        None
                    }
                };
                let _send_res = tx_start_inner.send(());
                debug!("Capture device starts now!");
                loop {
                    match command_channel.try_recv() {
                        Ok(CommandMessage::Exit) => {
                            debug!("Exit message received, sending EndOfStream.");
                            let msg = AudioMessage::EndOfStream;
                            channel.send(msg).unwrap_or(());
                            status_channel.send(StatusMessage::CaptureDone).unwrap_or(());
                            break;
                        }
                        Ok(CommandMessage::SetSpeed { speed }) => {
                            rate_adjust = speed;
                            debug!("Requested to adjust capture speed to {speed}.");
                            if let Some(resampl) = &mut resampler {
                                debug!("Adjusting resampler rate to {speed}.");
                                if async_src {
                                    if resampl.resampler.set_resample_ratio_relative(speed, true).is_err() {
                                        debug!("Failed to set resampling speed to {speed}.");
                                    }
                                }
                                else {
                                    warn!("Requested rate adjust of synchronous resampler. Ignoring request.");
                                }
                            }
                        },
                        Err(crossbeam_channel::TryRecvError::Empty) => {}
                        Err(crossbeam_channel::TryRecvError::Disconnected) => {
                            error!("Command channel was closed.");
                            break;
                        }
                    };
                    match rx_state_dev.try_recv() {
                        Ok(DeviceState::Ok(_)) => {},
                        Ok(DeviceState::Error(err)) => {
                            channel.send(AudioMessage::EndOfStream).unwrap_or(());
                            send_error_or_captureformatchange(&status_channel, &rx_disconnectreason, err);
                            break;
                        },
                        Err(TryRecvError::Empty) => {}
                        Err(TryRecvError::Disconnected) => {
                            channel.send(AudioMessage::EndOfStream).unwrap_or(());
                            send_error_or_captureformatchange(&status_channel, &rx_disconnectreason, "Inner capture thread exited.".to_string());
                            break;
                        }
                    }
                    capture_frames = nbr_capture_frames(
                        &resampler,
                        capture_frames,
                    );
                    let capture_bytes = blockalign * capture_frames;
                    while device_consumer.occupied_len() < (blockalign * capture_frames) {
                        trace!("Capture device needs more samples to make chunk, reading from channel.");
                        match rx_dev.recv() {
                            Ok((chunk_nbr, data_bytes)) => {
                                trace!("Capture, received chunk, length {data_bytes} bytes.");
                                expected_chunk_nbr += 1;
                                if data_bytes == 0 {
                                    if state != ProcessingState::Stalled {
                                        trace!("Capture device became inactive.");
                                        saved_state = state;
                                        state = ProcessingState::Stalled;
                                    }
                                    break;
                                }
                                else if state == ProcessingState::Stalled {
                                    trace!("Capture device became active.");
                                    state = saved_state;
                                }
                                if chunk_nbr > expected_chunk_nbr {
                                    warn!("Capture, samples were dropped, missing {} buffers.", chunk_nbr - expected_chunk_nbr);
                                    expected_chunk_nbr = chunk_nbr;
                                }
                            }
                            Err(err) => {
                                error!("Capture, channel is closed.");
                                channel.send(AudioMessage::EndOfStream).unwrap_or(());
                                send_error_or_captureformatchange(&status_channel, &rx_disconnectreason, err.to_string());
                                return;
                            }
                        }
                    }
                    // Drain any remaining messages in the rx_dev channel
                    while let Ok((chunk_nbr, data_bytes)) = rx_dev.try_recv() {
                        trace!("Capture, drained chunk notification, length {data_bytes} bytes.");
                        expected_chunk_nbr = chunk_nbr;
                    }
                    if state != ProcessingState::Stalled {
                        device_consumer.pop_slice(&mut data_buffer[0..capture_bytes]);
                        averager.add_value(capture_frames);
                        if let Some(capture_status) = capture_status.try_upgradable_read() {
                            if averager.larger_than_millis(capture_status.update_interval as u64)
                            {
                                let samples_per_sec = averager.average();
                                averager.restart();
                                let measured_rate_f = samples_per_sec;
                                if let Ok(mut capture_status) = RwLockUpgradableReadGuard::try_upgrade(capture_status) {
                                    capture_status.measured_samplerate = measured_rate_f as usize;
                                    capture_status.signal_range = value_range as f32;
                                    capture_status.rate_adjust = rate_adjust as f32;
                                    capture_status.state = state;
                                }
                                else {
                                    xtrace!("Capture status upgrade blocked, skip update.");
                                }
                            }
                        }
                        else {
                            xtrace!("Capture status blocked, skip update.");
                        }
                        watcher_averager.add_value(capture_frames);
                        if watcher_averager.larger_than_millis(rate_measure_interval)
                        {
                            let samples_per_sec = watcher_averager.average();
                            watcher_averager.restart();
                            let measured_rate_f = samples_per_sec;
                            debug!(
                                "Capture, measured sample rate is {measured_rate_f:.1} Hz."
                            );
                            let changed = valuewatcher.check_value(measured_rate_f as f32);
                            if changed {
                                warn!("Sample rate change detected, last rate was {measured_rate_f} Hz.");
                                if stop_on_rate_change {
                                    let msg = AudioMessage::EndOfStream;
                                    channel.send(msg).unwrap_or(());
                                    status_channel.send(StatusMessage::CaptureFormatChange(measured_rate_f as usize)).unwrap_or(());
                                    break;
                                }
                            }
                        }
                        let mut chunk = buffer_to_chunk_rawbytes(
                            &data_buffer[0..capture_bytes],
                            channels,
                            &binary_format,
                            capture_bytes,
                            &capture_status.read().used_channels,
                            false,
                        );
                        chunk.update_stats(&mut chunk_stats);
                        crate::update_capture_signal_status(
                            &capture_status,
                            &chunk_stats,
                            &mut rms_values,
                            &mut peak_values,
                        );
                        value_range = chunk.maxval - chunk.minval;
                        state = silence_counter.update(value_range);
                        if state == ProcessingState::Running {
                            if let Some(resampl) = &mut resampler {
                                resampl.resample_chunk(&mut chunk, chunksize, channels);
                            }
                            let msg = AudioMessage::Audio(chunk);
                            if channel.send(msg).is_err() {
                                info!("Processing thread has already stopped.");
                                break;
                            }
                        }
                    }
                    if state == ProcessingState::Paused || state == ProcessingState::Stalled {
                        let msg = AudioMessage::Pause;
                        if channel.send(msg).is_err() {
                            info!("Processing thread has already stopped.");
                            break;
                        }
                    }
                }
                if let Some(h) = thread_handle {
                    match demote_current_thread_from_real_time(h) {
                        Ok(_) => {
                            debug!("Capture outer thread returned to normal priority.")
                        }
                        Err(_) => {
                            warn!("Could not bring the outer capture thread back to normal priority.")
                        }
                    };
                }
                stop_signal.store(true, Ordering::Relaxed);
                debug!("Wait for inner capture thread to exit.");
                innerhandle.join().unwrap_or(());
                capture_status.write().state = ProcessingState::Inactive;
            })?;
        Ok(Box::new(handle))
    }
}
